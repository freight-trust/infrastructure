$ kubectl rollout status deployment app
deployment "app" successfully rolled out