$ kubectl rollout undo deployment app
deployment.extensions/app rolled back