local function foo(applet)
    -- perform logic here
end

core.register_service("foo_name", "[mode]", foo)
