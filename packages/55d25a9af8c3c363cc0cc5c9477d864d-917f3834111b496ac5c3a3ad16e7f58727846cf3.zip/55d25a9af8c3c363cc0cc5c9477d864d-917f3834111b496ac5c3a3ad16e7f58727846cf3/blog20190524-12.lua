local function foo(value)
    -- perform logic here
end

core.register_converters("foo_conv", foo)
