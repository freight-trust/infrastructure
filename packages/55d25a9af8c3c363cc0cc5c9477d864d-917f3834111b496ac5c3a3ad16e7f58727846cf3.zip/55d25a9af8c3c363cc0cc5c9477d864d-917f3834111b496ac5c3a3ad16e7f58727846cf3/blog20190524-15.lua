local function foo(txn)
    -- perform logic here
end

core.register_action("foo_action", { 'tcp-req', 'tcp-res', 'http-req', 'http-res' }, foo, 0)
