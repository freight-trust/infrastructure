$ export FLASK_APP=ipchecker.py
$ flask run
 * Serving Flask app "ipchecker"
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
