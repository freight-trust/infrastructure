local function log_work()
    while true do
        core.Debug("Doing some task work!\n")
        core.msleep(10000)
    end
end

core.register_task(log_work)
