local function foo(txn, [param1], [param2], [etc.])
    -- perform logic here
end

core.register_fetches("foo_fetch", foo)
