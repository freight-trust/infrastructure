import random
from flask import Flask
app = Flask(__name__)

@app.route("/<address>")
def check(address=None):
    myrandom = random.randint(0, 1)
    if myrandom > 0:
        return 'allow'
    else:
        return 'deny'
