local function foo()
    -- perform logic here
end

core.register_task(foo)
