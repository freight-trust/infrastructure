$ haproxy -vv | grep Lua
Built with Lua version : Lua 5.3.5
