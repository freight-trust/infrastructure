$ sudo systemctl status haproxy

haproxy.service - HAProxy Load Balancer
 Main PID: 1177 (haproxy)
    Tasks: 14 (limit: 1152)
   CGroup: /system.slice/haproxy.service
           ├─1177 /usr/sbin/haproxy -Ws -f /etc/haproxy/haproxy.cfg -p /run/haproxy.pid -S /run/haproxy-master.sock -sf 1209
           ├─2081 spoa-mirror --runtime 0 --mirror-url http://localhost:81 --address 127.0.0.1
           └─2082 /usr/sbin/haproxy -Ws -f /etc/haproxy/haproxy.cfg -p /run/haproxy.pid -S /run/haproxy-master.sock -sf 1209
