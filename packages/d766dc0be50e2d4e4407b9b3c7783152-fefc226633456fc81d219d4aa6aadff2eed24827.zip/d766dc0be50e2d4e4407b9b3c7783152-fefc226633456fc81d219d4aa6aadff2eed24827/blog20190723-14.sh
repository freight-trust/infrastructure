# Change mirroring to off
$ echo "set map /etc/haproxy/mirroring.map mirroring off" | nc 127.0.0.1 9999

# Show current value
$ echo "show map /etc/haproxy/mirroring.map mirroring" | nc 127.0.0.1 9999
