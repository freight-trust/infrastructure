# Show existing filters
curl -X GET --user admin:mypassword "http://localhost:5555/v1/services/haproxy/configuration/filters?parent_name=fe_main&parent_type=frontend"

# Add a filter line
curl -X POST --user admin:mypassword "http://localhost:5555/v1/services/haproxy/configuration/filters?parent_name=fe_main&parent_type=frontend&version=1" -H "Content-Type: application/json" -d '{"id": 0, "spoe_config":"/etc/haproxy/spoa.conf", "spoe_engine":"mirror", "type": "spoe"}'
{"id":0,"spoe_config":"/etc/haproxy/spoa.conf","spoe_engine":"mirror","type":"spoe"}

# Remove a filter line
curl -X DELETE --user admin:mypassword "http://localhost:5555/v1/services/haproxy/configuration/filters/0?parent_name=fe_main&parent_type=frontend&version=2" -H "Content-Type: application/json"
