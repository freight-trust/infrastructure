$ sudo apt update
$ sudo apt install -y autoconf automake build-essential git libcurl4-openssl-dev libev-dev libpthread-stubs0-dev pkg-config
$ git clone https://github.com/haproxytech/spoa-mirror
$ cd spoa-mirror
$ ./scripts/bootstrap
$ ./configure
$ make all
$ sudo cp ./src/spoa-mirror /usr/local/bin/