# TODO

* [Adduser consistency](https://github.com/hardening-io/chef-os-hardening/pull/73)
* [add support for limiting password re-use](https://github.com/hardening-io/puppet-os-hardening/pull/61)
