$ kubectl get namespaces
NAME     STATUS   AGE
default  Active   4m33s
dev      Active   2m38s
